Assignment #3: Ray tracing



FULL NAME: !!!replaceme!!!




MANDATORY FEATURES

------------------



<Under "Status" please indicate whether it has been implemented and is

functioning correctly.  If not, please explain the current status.>



Feature:                                 Status: finish? (yes/no)

-------------------------------------    -------------------------

1) Ray tracing triangles                  !!!no, explain!!!


2) Ray tracing sphere                     !!!no, explain!!!


3) Triangle Phong Shading                 !!!no, explain!!!


4) Sphere Phong Shading                   !!!no, explain!!!


5) Shadows rays                           !!!no, explain!!!


6) Still images                           !!!no, explain!!!
   

7) Extra Credit (up to 20 points)
   
   !!! explain your extra credit here, if applicable !!!
