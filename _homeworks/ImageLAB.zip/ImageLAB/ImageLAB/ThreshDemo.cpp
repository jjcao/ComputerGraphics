#include "ImgProc.h"
#include <iostream>
#include <string.h>
// ȫ�ֱ���
int threshold_value = 69;
int const max_value = 255;
const std::string window_name = "thresh_demo";
const std::string trackbar_value = "Value";
cv::Mat src;

//�ֲ���������
void thresh_demo(int, void*);

void ThreshDemo(const cv::Mat& img)
{
	src = img.clone();
	cv::namedWindow(window_name, cv::WINDOW_AUTOSIZE);
	cv::Mat bw;
	ImageLAB::threshold(src, bw, threshold_value);
	cv::imshow(window_name, bw);
	cv::createTrackbar( trackbar_value,
		                window_name, &threshold_value,
		                max_value, thresh_demo);
	while(true)
	{
		int c;
		c = cv::waitKey(20);
		if ((char)c == 27)
			break;
	}
}

void thresh_demo(int, void*)
{
	cv::Mat bw;
	ImageLAB::threshold(src, bw, threshold_value);
	cv::imshow(window_name, bw);
}