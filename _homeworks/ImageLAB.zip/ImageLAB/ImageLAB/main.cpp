#include "ImgProc.h"
#include "MainLab.h"

int main(void) 
{
	cv::Mat img = cv::imread("hehe.jpg", 0);
	ThreshDemo(img);
	return 0;
}